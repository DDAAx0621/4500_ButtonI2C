#include <atmel_start.h>

uint8_t debugHOLD;

// STRUCTS FOR I2C IO
struct io_descriptor *i2c_bus_io;


#define GPIOX_1_ADDR	0x38 //AD0 -> GND | AD1 -> GND | AD2 -> GND | #NOTE THIS IS FOR PCA9674A
#define GPIOX_2_ADDR	0x39 //AD0 -> VCC | AD1 -> GND | AD2 -> GND | #NOTE THIS IS FOR PCA9674A
#define GPIOX_3_ADDR	0x3A //AD0 -> GND | AD1 -> VCC | AD2 -> GND | #NOTE THIS IS FOR PCA9674A
#define GPIOX_4_ADDR	0x3B //AD0 -> VCC | AD1 -> VCC | AD2 -> GND	| #NOTE THIS IS FOR PCA9674A
#define EEPROM_ADDR		0xA1 //AD0 -> GND | AD1 -> GND | AD2 -> GND | 
#define AS5600_ADDR		0x6D // NOT USER SETTABLE

// MACROS FOR SETTING GPIOX PIN STATES
#define SET_BIT( val, pos) (val |= 1U << pos)
#define CLEAR_BIT(val, pos) (val &= (~(1U << pos)))


// DEFINING COMMANDS
	// PCA9674A COMMANDS
	#define PCA9674A_RST	0x00
	#define PCA9674A_GID	0x7C
	#define PCA9674A_CLP	0x00
	
	// EEPROM COMMANDS
	
	// AS5600 COMMANDS
	
// GENERAL I2C FUNCTIONS
void InitI2C_0();
void I2C_0_write(uint8_t address, uint8_t data, uint8_t *buffer, uint8_t buff_size);

// PC9674A FUNCTIONS


int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	
	//struct io_descriptor *I2C_0_io;
	uint8_t		command_data  = 0;
	
	uint8_t gpioX_POS = 0;
	uint8_t gpioX_VAL = 0;
	
	uint8_t *ptr1 ;
	
	bool on_CYC = true;
	
	bool wifien_FLAG = false;
	bool press_FLAG1 = false;
	bool press_FLAG2 = false;
	bool press_FLAG3 = false;
	bool press_FLAG4 = false;
	bool press_FLAG5 = false;
	bool press_FLAG6 = false;
	
		
	InitI2C_0();
	
	I2C_0_write((uint8_t)GPIOX_1_ADDR, (uint8_t)PCA9674A_RST, (uint8_t)PCA9674A_RST,1);
	//I2C_0_write((uint8_t)GPIOX_2_ADDR, (uint8_t)PCA9674A_RST, command_data,2);
	
	//i2c_m_sync_set_slaveaddr(&I2C_0, GPIOX_1_ADDR, I2C_M_SEVEN);
	//i2c_m_sync_cmd_write(&I2C_0, (uint8_t)PCA9674A_RST,&command_data,2);
	
	
	
	//i2c_m_sync_cmd_read(&I2C_0,(uint8_t)PCA9674A_GID,&command_data,2);

	/* Replace with your application code */
	while (1) 
	{
		
		
		if (on_CYC == true)	
			gpioX_VAL = SET_BIT(gpioX_VAL,gpioX_POS);
		else
			gpioX_VAL  = CLEAR_BIT(gpioX_VAL,gpioX_POS);
			
		uint8_t buf_val = gpioX_VAL;
				 
		
		I2C_0_write((uint8_t)GPIOX_1_ADDR, gpioX_VAL, gpioX_VAL,1);
		
		delay_ms(100);
		//command_data[0] = 0x00;
			
		if (gpioX_POS < 8)
			gpioX_POS++;
		else
		{
			gpioX_POS = 0;
			
			if (on_CYC == true)
				on_CYC = false;
			else
				on_CYC = true;
		}
		
		
		
	}
}


// GENERAL I2C FUNCTIONS
void InitI2C_0()
{
	i2c_m_sync_get_io_descriptor(&I2C_0, &i2c_bus_io);
	
	i2c_m_sync_enable(&I2C_0);
}

void I2C_0_write(uint8_t address, uint8_t data, uint8_t *buffer, uint8_t buff_size)
{
	i2c_m_sync_set_slaveaddr(&I2C_0, address, I2C_M_SEVEN);
	
	i2c_m_sync_cmd_write(&I2C_0,data, &buffer, buff_size);
	//delay_ms(1);	
}
//int32_t i2c_m_sync_cmd_write(struct i2c_m_sync_desc *i2c, uint8_t reg, uint8_t *buffer, uint8_t length)

// PCA9674 FUNCTIONS

